"""Flask configuration."""
from os import environ, path
from dotenv import load_dotenv
from datetime import timedelta

basedir = path.abspath(path.dirname(__file__))
#print(basedir)
load_dotenv(path.join(basedir, '.env'))


class Config:
    """Base config."""
    SECRET_KEY          = environ.get('SECRET_KEY')
    
    STATIC_FOLDER       = 'static'
    TEMPLATES_FOLDER    = 'templates'

    ## session configs
    PERMANENT_SESSION_LIFETIME   = timedelta(minutes=20)
    SESSION_USE_SIGNER = True
    SESSION_PERMANENT  = True
    SESSION_TYPE       = "filesystem"
    REDIS_URL          = 'redis://gtt-india-app-qa-elasticache-redis.gu0csy.ng.0001.use1.cache.amazonaws.com:6379'



class ProdConfig(Config):
    FLASK_ENV = 'production'
    DEBUG     = False
    TESTING   = False
    #DATABASE_URI = environ.get('PROD_DATABASE_URI')
    SESSION_COOKIE_NAME = environ.get('SESSION_COOKIE_NAME')
    SESSION_COOKIE_DOMAIN = environ.get('SESSION_COOKIE_DOMAIN')

    PASSWORD  =  environ.get('PASSWORD')
    DATABASE  =  environ.get('DATABASE')
    USER      =  environ.get('USER')
    ACCOUNT   =  environ.get('ACCOUNT')
    WAREHOUSE =  environ.get('WAREHOUSE')
    SCHEMA    =  environ.get('SCHEMA')
    ROLE      =  environ.get('ROLE')

class DevConfig(Config):
    FLASK_ENV  = 'development'
    DEBUG      = True
    TESTING    = True
    
    PASSWORD  =  environ.get('DEV_PASSWORD')
    DATABASE  =  environ.get('DEV_DATABASE')
    USER      =  environ.get('DEV_USER')
    ACCOUNT   =  environ.get('DEV_ACCOUNT')
    WAREHOUSE =  environ.get('DEV_WAREHOUSE')
    SCHEMA    =  environ.get('DEV_SCHEMA')
    ROLE      =  environ.get('DEV_ROLE')

class QaConfig(Config):
    FLASK_ENV  = 'development'
    DEBUG      = True
    TESTING    = True
    
    PASSWORD  =  environ.get('QA_PASSWORD')
    DATABASE  =  environ.get('QA_DATABASE')
    USER      =  environ.get('QA_USER')
    ACCOUNT   =  environ.get('QA_ACCOUNT')
    WAREHOUSE =  environ.get('QA_WAREHOUSE')
    SCHEMA    =  environ.get('QA_SCHEMA')
    ROLE      =  environ.get('QA_ROLE')