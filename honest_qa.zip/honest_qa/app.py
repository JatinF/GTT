import os, json
import requests

from flask import Flask,  render_template, redirect,request,g,session,make_response,Response
from flask_session import Session
import json
from datetime import datetime,date,timedelta
 
from snowflake.sqlalchemy import URL
from sqlalchemy  import create_engine

#from werkzeug.local import LocalProxy
from config import Config 

app = Flask(__name__)

app.config.from_object('config.Config')

# Using a production configuration
#app.config.from_object('config.ProdConfig')


# Using a development configuration
#app.config.from_object('config.DevConfig')

app.config.from_object('config.QaConfig')

from commoncls import CustomJsonEncoder,execute_snowflake_query,COLORS,check_special_chars,get_practice_data,get_providers
from middleware import check_login_user,check_gttval_cookie

sess = Session(app)

@app.route('/')
@app.route('/index')
def index():

    print("inside home page #####")
    print(session)
    return render_template(
        'login.html'
    )

@app.route("/login", methods=["POST", "GET"])
#@check_gttval_cookie
def login():

    print("inside login ########")
    print(request.args)

    if 'internal' in request.args:
        #print('sssssssssssss')
        session['user_name'] = ('KT00741141@TECHMAHINDRA.COM','KT00741141@TechMahindra.com')
    
    if 'external' in request.args:
        session['user_name'] = ('KDEBADHARSHINIT@GERMANTOWNTECH.IN','kdebadharshinit@germantowntech.in')
    
    print("session user name :",session['user_name'])
    user_rows   = execute_snowflake_query(f""" select USERTYPE,JVNAME,JVREF from VW_PORTAL_USERS where USERTYPE is not null and USERNAME  in {session['user_name']} """)
    # print(f""" select USERTYPE,JVNAME,JVREF from VW_PORTAL_USERS where USERTYPE is not null and USERNAME in {session['user_name']} """)
    # print(user_rows)
    if user_rows:
        session['user_type'] = user_rows[0][0]
        session['jv_name']   = user_rows[0][1]
        session['jv_ref']    = user_rows[0][2]

    else:
        #print("gttvalue cookie doesnot exist")
        session['user_type'] = ''
        session['jv_name']   = ''
        session['jv_ref']    = ''

        return Response('Authorization Failed. Please log-in and try again.....', mimetype='text/plain',status=401)

    print(session)
    return redirect("/dashboard")


@app.route('/dashboard', methods=['GET'])
#@check_gttval_cookie
@check_login_user
def dashboard():
    print("inside dashbaord #####")
    print(session)
    #print(session.get('user_name'))
    partner_data,sel_year,py_count,no_ly_count,ly_count = [],2022,0,0,0 
    staff_name      = session['user_name']
    partner_filter  = session['jv_name'] if 'user_type' in session and session['user_type'] == 'ExternalUser' else ''
    ## get the partner names  
    partner_cond   =  '' 
    if partner_filter!='':
        partner_cond   =  f""" WHERE JVPARTNERID = {session['jv_ref']} """
    partner_rows   = execute_snowflake_query(f""" select JVPARTNERID,JVPNAME from DIM_JVPARTNER {partner_cond}""")
    #staff_rows     = staff_result.fetchall()
    partner_data   = {x[0]:x[1] for x in partner_rows if x[0] !=''}    #[x[0] for x in staff_rows if x[0] !='']    

   
    return render_template('dashboard.html',data=[partner_data,sel_year,'','',ly_count,staff_name,partner_filter])

@app.route('/get_practice_data', methods=['GET'])
def load_practices():
    prc_data = get_practice_data()
    #print(pro_data)
    return  json.dumps(prc_data)

@app.route('/get_provider_data', methods=['GET'])
def get_provider_data():
    pro_data = get_providers()
    #print(pro_data)
    return  json.dumps(pro_data)



@app.route('/get_staff_users', methods=['POST', 'GET'])
def get_staff_users():

    err_flg = check_special_chars()
    where_cond = ""
    if err_flg==0:
        from_date    = request.args.get('from_date') or ''
        to_date      = request.args.get('to_date') or ''
        conditions   = []
        if from_date!='':
            from_date    = datetime.strptime(from_date,'%d-%m-%Y').strftime("%Y-%m-%d")
            conditions.append(f" CONDATE >= '{from_date}' ")
        if to_date!='':
            to_date    = datetime.strptime(to_date, '%d-%m-%Y').strftime("%Y-%m-%d")
            conditions.append(f" CONDATE <= '{to_date}' ") 
        
        if len(conditions)>0:        
            where_cond = " where "+(" and ".join(conditions))

    staff_rows  = execute_snowflake_query(f"""select STAFF_USER_NAME from DIM_INTERACTION {where_cond} group by STAFF_USER_NAME """)
    staff_data  = sorted([x[0] for x in staff_rows if x[0] !=''])       
    
    return json.dumps(staff_data)

## :: 5-D Dashboard
@check_login_user
def get_yearly_statistics(default_yr):
    # print("yearly statistics#####")
    # print(session)
    err_flg = check_special_chars()
    py_where,no_ly_where,ly_where,pt_where = "","","",""
    if err_flg==0:
        py_where    = construct_where_condition(f""" where year(PY_AWVDATE) = {default_yr} """,1)
        no_ly_where = construct_where_condition(" where LY_AWVDATE is null ",1)
        ly_where    = construct_where_condition(f""" where year(LY_AWVDATE) ={(default_yr-1)} """,1)
        pt_where    = construct_where_condition("",1)

    py_count,no_ly_count,ly_count = 0,0,0
    py_rows     = execute_snowflake_query(f""" select count(1) as py_count from VW_FIVED_SCREEN {py_where} """)
    py_count    = py_rows[0][0]

    no_ly_rows   = execute_snowflake_query(f""" select count(1) as no_ly_count from VW_FIVED_SCREEN {no_ly_where} """)
    no_ly_count  = no_ly_rows[0][0]

    ly_rows     = execute_snowflake_query(f""" select count(1) as ly_count from VW_FIVED_SCREEN {ly_where} """)
    ly_count    = ly_rows[0][0]

    pt_rows     = execute_snowflake_query(f""" select COUNT (DISTINCT PATIENT_ID) from VW_FIVED_SCREEN {pt_where} """)
    pt_count    = pt_rows[0][0]

    return py_count,no_ly_count,ly_count,pt_count

@app.route('/get_yearly_counts', methods=['POST', 'GET'])
def get_yearly_counts():

    default_yr = int(request.args.get('sel_year')) or date.today().year
    py_count,no_ly_count,ly_count,pt_count = get_yearly_statistics(default_yr)
   
    #return py_count,no_ly_count,ly_count
    return json.dumps([py_count,no_ly_count,ly_count,pt_count])

## :: 5-D Dashboard
@app.route('/plot_provider_graph', methods=['POST', 'GET'])
@check_login_user
def plot_provider_graph():
   
    where_cond = " where STAFF_USER_NAME!='' "  

    err_flg = check_special_chars()
    if err_flg==0:  
        where_cond = construct_where_condition(where_cond,1)

    # print("provider graph ############")
    # print(where_cond)
    
    rows = execute_snowflake_query(f""" select count(1) as status_count,STAFF_USER_NAME,STATUS_DESCRIPTION from VW_FIVED_SCREEN {where_cond} group by STAFF_USER_NAME,STATUS_DESCRIPTION """)
    staff_names     = sorted(list(set(month_data[1] for month_data in rows)))

    status_vals     = sorted(list(set(month_data[2] for month_data in rows))) 
    all_dict_data   = dict()

    for status in status_vals:
        all_dict_data[f"{status}_dict"]  = {provider_data[1]:provider_data[0] for provider_data in rows if provider_data[2] == status} 

    all_status_data = []
    
    col_cntr    = 0
    for status in status_vals:
        status_data = [all_dict_data[f"{status}_dict"][staff_name] if staff_name in all_dict_data[f"{status}_dict"] else 0 for staff_name in staff_names]
        all_status_data.append({
            'x'   : status_data ,
            'y'   : [str(data) for data in staff_names], #.replace(" ", " <br> ")
            'text': [str(data) for data in status_data],
            "name": status,
            "type": 'bar',
            "orientation": 'h',
            "marker":{
                'color': COLORS[col_cntr]
            }
        })
        col_cntr+=1
    
    return json.dumps(all_status_data)

## get programme type wise statistics :: 5-D Dashboard
@app.route('/plot_donut_graph', methods=['POST', 'GET'])
@check_login_user
def plot_donut_graph():
  
    where_cond = ''    
    err_flg = check_special_chars()
    if err_flg==0:  
        where_cond = construct_where_condition("",1)
    #print(where_cond)  
    sts_colr      = ['rgba(0,127,152,1)','rgba(233,173,8,1)','rgba(70,91,120,1)','rgba(43,188,101,1)','rgba(70,91,120,1)']

    status_rows = execute_snowflake_query(f""" select STATUS_DESCRIPTION, count(1) as status_count from EDW.VW_FIVED_SCREEN {where_cond} group by STATUS_DESCRIPTION""")
    status_data = [{
        'values': [status[1] for status in status_rows],
        'labels': [status[0] for status in status_rows],
        'type': 'pie',
        "marker":{
                'colors': sts_colr
            }
        }]
        
    return json.dumps(status_data)

## :: 5-D Dashboard
@app.route('/plot_jv_partner_graph', methods=['POST', 'GET'])
@check_login_user
def plot_jv_partner_graph():
    where_cond       = ''
    #print(where_cond)
    err_flg = check_special_chars()
    if err_flg==0:  
        where_cond = construct_where_condition("",1)

    rows             = execute_snowflake_query(f""" select count(1) as partner_count,JVPARTNER_NAME,STATUS_DESCRIPTION from VW_FIVED_SCREEN {where_cond} group by JVPARTNER_NAME,STATUS_DESCRIPTION """)
    partner_names    = sorted(list(set(month_data[1] for month_data in rows))) 

    completed_data   = []

    completed_dict   = {provider_data[1]:provider_data[0] for provider_data in rows if provider_data[2] == 'COMPLETED'}
    #print(completed_dict)
    for partner_name in partner_names: 
        tot_val  = 0
        comp_val = completed_dict[partner_name] if partner_name in completed_dict else 0
        
        for provider_data in rows:
            if provider_data[1] == partner_name:
                tot_val  += provider_data[0] 

        completed_data.append(round((comp_val *100/tot_val),2))

        
    trace1 = {
        'x': partner_names,
        'y': completed_data,
        'text': [str(data)+"%" for data in completed_data],
        "type": 'bar',
        "marker":{
                'color': COLORS[2]
        }
    }
    
    return json.dumps([trace1])

## :: 5-D Dashboard
@app.route('/plot_monthly_completion_graph', methods=['POST', 'GET'])
@check_login_user
def plot_monthly_completion_graph():
    
    where_cond = " WHERE STATUS_DESCRIPTION ='COMPLETED' "  
    tot_where_cond = ''
    err_flg     = check_special_chars()
    if err_flg==0:  
        where_cond = construct_where_condition(where_cond,1)        
        tot_where_cond = construct_where_condition("",1)
    #print(where_cond)
    tot_rows = execute_snowflake_query(f""" SELECT COUNT(PATIENT_ID) as total_count FROM VW_FIVED_SCREEN {tot_where_cond}  """)
    tot_rec_count = tot_rows[0][0]

    rows = execute_snowflake_query(f""" SELECT  month(COMPLETION_DATE) as comp_month,MONTHNAME(COMPLETION_DATE) as comp_month_name,COUNT(1) as completed_count
    FROM VW_FIVED_SCREEN {where_cond} GROUP BY month(COMPLETION_DATE),MONTHNAME(COMPLETION_DATE) ORDER BY 1,2 
    """)
  
    all_month_data   = ['Jan', 'Feb', 'Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    todays_date = date.today()
    sel_year    = request.args.get('sel_year') or todays_date.year
    if todays_date.year == int(sel_year):
        cur_month_idx    = todays_date.month
        all_month_data   = all_month_data[:cur_month_idx]

        
    res                   = {month_data[1]: month_data[2] for month_data in rows}
    all_month_count_data  = [res[month] if month in res else 0 for month in all_month_data ]  

    all_month_count_percent_data  = [round(((res[month])*100/tot_rec_count),2) if month in res else 0 for month in all_month_data ] 

    #print(tot_rec_count) 
        
    monthly_bar_data = [
            {            
                'x'   :all_month_data,
                'y'   :all_month_count_data,
                'type': 'bar',
                'text': [str(i) for i in all_month_count_data],
                "marker":{'color': COLORS[2]}
            }
        ]
    monthly_percent_bar_data = [{            
            'x'   :all_month_data,
            'y'   :all_month_count_percent_data,
            'type': 'scatter',
            'text': [str(i)+'%' for i in all_month_count_percent_data],
            "marker":{'color': COLORS[2]}
        }]
    
    return json.dumps([monthly_bar_data,monthly_percent_bar_data])
## :: 5-D Dashboard
@app.route('/plot_practice_status_graph', methods=['POST', 'GET'])
@check_login_user
def plot_practice_status_graph():
    where_cond      = ' WHERE PRACTICE_ID is not null '
    err_flg         = check_special_chars()
    
    #print(where_cond)
    partner_filter  = session['jv_name'] if 'user_type' in session and session['user_type'] == 'ExternalUser' else '' 
    if partner_filter!='':
        where_cond   +=  f""" AND PRACTICE_ID in (select PRACTICEID from DIM_PRACTICE where JVPARTNERID = {session['jv_ref']} ) """

    if err_flg==0:
        where_cond      = construct_where_condition(where_cond,1)

    rows            = execute_snowflake_query(f""" select count(1) as practice_count,concat_ws(' ',PRACTICE_ID,PRACTICE_NAME) as name,STATUS_DESCRIPTION from VW_FIVED_SCREEN {where_cond} group by PRACTICE_ID,PRACTICE_NAME,STATUS_DESCRIPTION """)
   
    pr_names        = sorted(list(set(pr_data[1] for pr_data in rows)))
    status_vals     = sorted(list(set(pr_data[2] for pr_data in rows))) 

    all_dict_data   = dict()
    for status in status_vals:
        all_dict_data[f"{status}_dict"]  = {practice_data[1]:practice_data[0] for practice_data in rows if practice_data[2] == status} 

    all_status_data = []    
    prct_ctr =0 
    for status in status_vals:
        status_data = [all_dict_data[f"{status}_dict"][pr_name] if pr_name in all_dict_data[f"{status}_dict"] else 0 for pr_name in pr_names]
        all_status_data.append({
            'x'   : status_data ,
            'y'   : pr_names,
            'text': [str(data) for data in status_data],
            "name": status,
            "type": 'bar',
            "orientation": 'h',
            "marker":{'color': COLORS[prct_ctr]}
        })
        prct_ctr+=1
    
    return json.dumps(all_status_data)


## function to get the requested data and form the where condition
def construct_where_condition(where_cond,date_cond):

    sel_year     = request.args.get('sel_year') or ''
    sel_partner  = request.args.get('sel_partner') or ''
    active_sts   = '1' #request.args.get('active_sts') or ''
    sel_practice = request.args.get('sel_practice') or ''  
    staff_id     = request.args.get('staff_id') or ''  
   
    ##partner dashboard variables   
    reporting_month= request.args.get('sel_month') or ''
    reporting_year = request.args.get('sel_rep_year') or '' 
    patient_status = request.args.get('sel_patient_status') or ''
    partner_id     = request.args.get('sel_partner_id') or ''
    provider_id    = request.args.get('sel_provider') or '' 

    partner_filter_id = request.args.get('partner_filter_id') or ''

    conditions = []
    if sel_year!='':
        conditions.append(f"PERFORMANCEYEAR = '{sel_year}'") 
    
    if partner_id !='':
        conditions.append(f" JVPARTNERID = {partner_id} ") 

    if partner_filter_id !='' and  partner_id =='':
        conditions.append(f" JVPARTNERID = {partner_filter_id} ") 

    if reporting_month !='' or reporting_year !='':
        conditions.append("  AS_OF_DATE is not null ")
    if reporting_month !='' :
        conditions.append(f" month(AS_OF_DATE) = {reporting_month} ") 
    if reporting_year !='':
        conditions.append(f" year(AS_OF_DATE) = {reporting_year} ") 

    if active_sts!='':
        if active_sts =='1':
            conditions.append(f" ALIGNMENT_STATUS = '1' and ENROLLED_IND = '1' ") 
        elif active_sts =='0':
            conditions.append(f" (ALIGNMENT_STATUS = '0' or ENROLLED_IND = '0') ") 

    # if align_sts!='':
    #     conditions.append(f" ALIGNMENT_STATUS = '{align_sts}' ") 

    ##for 5D dashboard
    partner_filter_name  = session['jv_ref'] if 'user_type' in session and session['user_type'] == 'ExternalUser' else ''
    if partner_filter_name !='':
        sel_partner = ''
        conditions.append(f" JVPARTNERID = {partner_filter_name} ") 
    if sel_practice !='':
        conditions.append(f" PRACTICE_ID = {sel_practice} ") 
    if staff_id !='':
        conditions.append(f" STAFF_USER_NAME = '{staff_id}' ") 
    

    if sel_partner!='':
        conditions.append(f"JVPARTNERID = {sel_partner}") 

    #print(datetime.strptime(from_date, '%d-%m-%Y').strftime("%Y-%m-%d"))
    if date_cond:
        from_date    = request.args.get('from_date') or ''
        to_date      = request.args.get('to_date') or ''

        if from_date!='':
            from_date    = datetime.strptime(from_date,'%d-%m-%Y').strftime("%Y-%m-%d")
            conditions.append(f" COMPLETION_DATE >= '{from_date}' ")
        if to_date!='':
            to_date    = datetime.strptime(to_date, '%d-%m-%Y').strftime("%Y-%m-%d")
            conditions.append(f" COMPLETION_DATE <= '{to_date}' ") 

    if patient_status !='':
        conditions.append(f" PATIENTSTATUS = '{patient_status}' ") 
    
    if provider_id !='':
        conditions.append(f" SPECIALIST_NPI = '{provider_id}' ") 
    
    if len(conditions)>0:        
        if where_cond =='':
            where_cond = " where "+(" and ".join(conditions))
        else:
            where_cond += " and "+(" and ".join(conditions))

    return where_cond


if __name__ == '__main__':
    
    #sess.init_app(app)
    app.run(debug=False, port=5000, host='0.0.0.0')