#from werkzeug.wrappers import Request,Response
import base64
import requests
from functools import wraps
from flask import Response,request,g,session
#from flask_session import Session
import redis,json

from app import app

## creata a decorator for key validation
def key_validate_middleware(func):
    @wraps(func)
    def decorated_function(*args,**kwargs):

        enc_user_name = request.args.get('key') or ''
        print(encrypt_str('Remya V')) # UmVteWEgVg== UmFqYW5pIE11cmFsaQ==
        user_name     = decrypt_str(enc_user_name) if enc_user_name!='' else ''

        if user_name in ['Rajani Murali','Remya V','Manish John','Niranjan Mg','Shreyas J']:
            g.user_name = user_name 

            return func(*args,**kwargs)

        return Response('Authorization Failed', mimetype='text/plain',status=401)

    return decorated_function

def check_gttval_cookie(func):
    @wraps(func)
    def check_gtt(*args,**kwargs):

        rConn       = redis.from_url(app.config['REDIS_URL'])
        redisValstr = ''
        print('Request Session inside cookie middleware', request.cookies)
        if 'gttvalue' in  request.cookies :
            cookie = request.cookies['gttvalue'] 

            print('value in cookie', cookie)    
            cookieValDecoded = requests.utils.unquote(cookie)

            print('cookieValDecoded', cookieValDecoded)
            cookieVal = cookieValDecoded[2:].split('.')[0]

            print('cookieVal', cookieVal)
            try:
                redisValstr = rConn.get("sess:"+cookieVal) 
            except Exception as e:
                print('An exception occurred: {}'.format(e))
                redisValstr = ''
                pass

        else:
            return Response('Authorization Failed. Please log-in and try again...', mimetype='text/plain',status=401)  
        # static value
        #redisValstr = b'{"cookie":{"originalMaxAge":1200000,"expires":"2022-05-27T14:18:26.864Z","secure":false,"httpOnly":true,"domain":"localhost","path":"/"},"passport":{"user":{"issuer":"http://www.okta.com/exko342r2zxDXqDdY696","inResponseTo":"_a5f9350ac2ad6aa25267","sessionIndex":"_a5f9350ac2ad6aa25267","nameID":"kdebadharshinit@germantowntech.in","nameIDFormat":"urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified"}}}'

        if redisValstr:
            redisVal = json.loads(redisValstr)
            print('redisVal', redisVal)

            session['user_name'] = redisVal['passport']['user']['nameID']
            return func(*args,**kwargs)
        else:
            
            session.pop('user_name', None)
            return Response('Authorization Failed. Please log-in and try again.', mimetype='text/plain',status=401)

    return check_gtt

## creata a decorator for key validation
def check_login_user(func):
    @wraps(func)
    def decorated_function(*args,**kwargs):
        print("inside middleware ########")
        print(session)
        if session.get("user_name"):
            return func(*args,**kwargs)

        return Response('Authorization Failed. Please log-in and try again.', mimetype='text/plain',status=401)

    return decorated_function

## create a function for encrypt a raw string to base-64
def encrypt_str(raw_str):

    raw_str_bytes = raw_str.encode("ascii")  
    base64_bytes  = base64.b64encode(raw_str_bytes)
    base64_string = base64_bytes.decode("ascii")

    return base64_string
## create a function for decrypt a  base-64 string to raw string
def decrypt_str(encode_str):

    raw_string = ''
    try:
        base64_bytes        = encode_str.encode("ascii")  
        sample_string_bytes = base64.b64decode(base64_bytes)
        raw_string          = sample_string_bytes.decode("ascii")
    except Exception:
        pass
    return raw_string    

