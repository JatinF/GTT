

function plot_provider_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id) {
    //console.log(selection)
    $('#myDiv').html('<div class="loader"></div>')            
    $.getJSON({
         url: "/plot_provider_graph", data: {"from_date":from_date,"to_date":to_date,"sel_year":sel_year,"sel_partner":sel_partner,"sel_provider":sel_provider,"sel_practice":sel_practice,"staff_id":staff_id}, success: function (result) {                    
             $('#myDiv').html('')
             Plotly.newPlot('myDiv', result, {barmode: 'stack'});            
         }
     });
 }

function plot_donut_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id) {
    //console.log(selection)
    $('#piechart_div').html('<div class="loader"></div>')
     $.getJSON({
         url: "/plot_donut_graph", data: {"from_date":from_date,"to_date":to_date,"sel_year":sel_year,"sel_partner":sel_partner,"sel_provider":sel_provider,"sel_practice":sel_practice,"staff_id":staff_id}, success: function (result) {
             
                              
             $('#piechart_div').html('')
             Plotly.newPlot('piechart_div', result);
             
         }
     });
 }

 function plot_jv_partner_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id) {
    //console.log(selection)
    $('#jvparnerDiv').html('<div class="loader"></div>')            
    $.getJSON({
         url: "/plot_jv_partner_graph", data: {"from_date":from_date,"to_date":to_date,"sel_year":sel_year,"sel_partner":sel_partner,"sel_provider":sel_provider,"sel_practice":sel_practice,"staff_id":staff_id}, success: function (result) {                    
             $('#jvparnerDiv').html('')
             Plotly.newPlot('jvparnerDiv', result);            
         }
     });
 }

 function plot_monthly_completion_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id) {
    //console.log(selection)
    $('#monthlycompDiv').html('<div class="loader"></div>')
    $('#monthly_percent_div').html('<div class="loader"></div>') 

    $.getJSON({
         url: "/plot_monthly_completion_graph", data: {"from_date":from_date,"to_date":to_date,"sel_year":sel_year,"sel_partner":sel_partner,"sel_provider":sel_provider,"sel_practice":sel_practice,"staff_id":staff_id}, success: function (result) {                    
             $('#monthlycompDiv').html('')
             Plotly.newPlot('monthlycompDiv', result[0]); 

             $('#monthly_percent_div').html('')
             Plotly.newPlot('monthly_percent_div', result[1]);              
         }
     });
 }

 function plot_practice_status_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id) {
    //console.log(selection)
    $('#practiceDiv').html('<div class="loader"></div>')            
    $.getJSON({
         url: "/plot_practice_status_graph", data: {"from_date":from_date,"to_date":to_date,"sel_year":sel_year,"sel_partner":sel_partner,"sel_provider":sel_provider,"sel_practice":sel_practice,"staff_id":staff_id}, success: function (result) {                    
             $('#practiceDiv').html('')
             Plotly.newPlot('practiceDiv', result, {barmode: 'stack'});            
         }
     });
 }

function get_yearly_counts(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id){
    $('#py_count','#no_ly_count','#ly_count').html('')
    $.getJSON({
         url: "/get_yearly_counts", data: {"from_date":from_date,"to_date":to_date,"sel_year":sel_year,"sel_partner":sel_partner,"sel_provider":sel_provider,"sel_practice":sel_practice,"staff_id":staff_id}, success: function (result) {                    
             $('#py_count').html(result[0]) 
             $('#no_ly_count').html(result[1]) 
             $('#ly_count').html(result[2])   

             $('#patient_count').html(result[3])   
             
         }
     });     
} 
function load_all_graphs() {
    var from_date   = $('#from_date').val();
    var to_date     = $('#to_date').val();
    var sel_year    = $('#sel_year').val();
    var sel_partner = $('#sel_partner').val();
    var sel_provider= $('#sel_provider').val();
    var sel_practice= $('#sel_practice').val();

    var staff_id    = $('#sel_staff_user').val();
    
    //console.log(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice)

    get_yearly_counts(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id)
    plot_donut_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id)
    plot_provider_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id)
    plot_jv_partner_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id)
    plot_monthly_completion_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id)
    plot_practice_status_graph(from_date,to_date,sel_year,sel_partner,sel_provider,sel_practice,staff_id)
}

function get_staff_users(){
    var from_date   = $('#from_date').val();
    var to_date     = $('#to_date').val();
    $('#sel_staff_user').html('<option value="">--All--</option>');

    $.getJSON({
        url: "/get_staff_users", data: {"from_date":from_date,"to_date":to_date}, success: function (result) {  
            //console.log(result)                  
            result.forEach((value) => {                   
                $('#sel_staff_user').append('<option value="'+value+'">'+value+'</option>');
            }); 
            
        }
    }); 
}

function load_practice_data(partner_id){
   
    $('#sel_practice').html('<option value="">--All--</option>');
    $('#sel_provider').html('<option value="">--All--</option>');
    $.getJSON({
        url: "/get_practice_data", data: {"partner_id":partner_id}, success: function (result) {  
            //console.log(result)   
            
            Object.keys(result).forEach(key => {
                //console.log(key, result[key]);
                $('#sel_practice').append('<option value="'+key+'">'+result[key]+'</option>');
            });
                        
        }
    }); 
}


function load_provider_data(practice_id){
   
    $('#sel_provider').html('<option value="">--All--</option>');
    $.getJSON({
        url: "/get_provider_data", data: {"practice_id":practice_id}, success: function (result) {  
            //console.log(result)  
            Object.keys(result).forEach(key => {
                $('#sel_provider').append('<option value="'+key+'">'+result[key]+'</option>');
            });
                        
        }
    }); 
 }



$(function() { 

    $('.datepicker').datepicker({
        weekStart: 1,
        daysOfWeekHighlighted: "6,0",
        autoclose: true,
        todayHighlight: true,
       
    });
    //$('#datepicker').datepicker("setDate", new Date());
    
    $('#from_date,#to_date').change(function() { 
       //console.log("ssssssssss")
       get_staff_users()
    });

    get_staff_users()
    load_practice_data('');
    load_provider_data('');
    load_all_graphs() 

});