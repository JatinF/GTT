$(document).ready(function () {

    //dropdown Js
    $(document).on('click', '.selection-click', function (e) {
        var _that = $(this).closest('.select-box');
        //e.stopPropagation();
        $(document)
            .find('.selection-options')
            .removeClass('open');
        if ($(this).parent().find('.selection-options').hasClass('open')) {
            $(this)
                .parent()
                .find('.selection-options')
                .removeClass('open');
        } else {
            if (!$(this).hasClass('drop-up')) {
                $(this)
                    .parent()
                    .find('.selection-options')
                    .addClass('open');
                $(this)
                    .parent()
                    .find('.selection-options')
                    .show()
                    .animate({}, 100, function () {
                        $(this)
                            .position({
                                of: _that,
                                my: 'left+1 top+32',
                                at: 'left top',
                                collision: "flipfit"
                            })
                            .animate({
                                "opacity": 1
                            }, 100);

                    });
            } else {
                $(this)
                    .parent()
                    .find('.selection-options')
                    .addClass('open');
                $(this)
                    .parent()
                    .find('.selection-options')
                    .show()
                    .animate({}, 100, function () {
                        $(this)
                            .position({
                                of: _that,
                                my: 'left bottom-26',
                                at: 'left bottom',
                                collision: "flipfit"
                            })
                            .animate({
                                "opacity": 1
                            }, 100);

                    });
                console.log($(this));

            }
        }
    });

    $(document).on('click', '.selection-options > li', function (e) {
        e.stopPropagation();
        var putText = $(this).text();
        $(this)
            .parent()
            .prev()
            .text(putText);
        $(this)
            .parent()
            .prev('.selection-input')
            .val(putText);
        $(this)
            .parent()
            .removeClass('open');
    });

    $(document).on('click', function (e) {
        var container = $('.selection-options');
        var containerPrev = $('.selection-click');
        if (!container.is(e.target) && container.has(e.target).length === 0 && !containerPrev.is(e.target)) {
            container.removeClass('open');
        }
    });
    //dropdown Js
    $(".input-group > input").focus(function (e) {
        $(this).parent().addClass("input-group-focus");
      }).blur(function (e) {
        $(this).parent().removeClass("input-group-focus");
      });


});