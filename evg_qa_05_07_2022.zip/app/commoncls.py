import json
from decimal import Decimal
from flask import request,g,session

from datetime import  date

from snowflake.sqlalchemy import URL
from sqlalchemy  import create_engine

from app import app
from werkzeug.local import LocalProxy

COLORS      = [ 'rgba(43,188,101,1)','rgba(233,173,8,1)','rgba(0,127,152,1)','rgba(70,91,120,1)', 'rgba(0,127,152,1)']

class CustomJsonEncoder(json.JSONEncoder):

    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, date):
            return obj.strftime("%Y-%m-%d")

        return super(CustomJsonEncoder, self).default(obj)

def connect_to_database():
    db_handler = create_engine(URL(   
        role = app.config['ROLE'],
        user = app.config['USER'],
        password = app.config['PASSWORD'],
        account = app.config['ACCOUNT'],
        warehouse = app.config['WAREHOUSE'],
        database = app.config['DATABASE'],
        schema = app.config['SCHEMA']
    ))

    #print("inside db connection ## cmncls--------")
    engine_con = db_handler.connect()
    return engine_con

fd = {'_database': None}
def get_db(): 
    db = fd['_database']
    if not db : 
        fd['_database'] = connect_to_database()
        db = fd['_database']
    return db

with app.app_context():
    #Get DB connection from application's context
    connection = LocalProxy(lambda: get_db())

SPL_CHARS = "SLEEP(,benchmark(,<,>,%,',--,/*,/,$,\,)waitfor,delay,;,prompt(,onmouseover,alert(,onclick,onmouseout,oncontextmenu,ondblclick,onmousedown,onmouseenter,onmouseleave,onmousemove,onmouseup,onkeydown,onkeypress,onkeyup,onload,onscroll,onunload,onchange,onblur,<script>,</script>,<script,script,version(),table_schema,table_name,.table,information_schema,injectx,curl,wget,pwd,@print,eval(,exec(,netsh,system(,sysinfo,whoami,1=1,0=0,1 = 1,0 = 0,like'%,==,'1,'0,=',=\",1\",1\",x\",1-',one,'x,group by,UNION ALL,UNION,substring,pg_SLEEP,order by,like(,randomblob,limit 1,*/,^"

def execute_snowflake_query(query):

    #connection = connect_to_database()
    try:        
        db_rows   = execute_query(connection,query)
    except Exception as e :
        connection = connect_to_database()
        fd['_database'] = connection

        db_rows   = execute_query(connection,query)

    finally:
        #connection.close()
        pass

    return db_rows

def execute_query(connection,query):

    db_result   = connection.execute(f"""{query}""")
    return db_result.fetchall()

def get_providers():

    practice_id      = request.args.get('practice_id') or ''

    partner_filter  = session['jv_name'] if 'user_type' in session and session['user_type'] == 'ExternalUser' else ''
    ## get the partner names  
    where_cond   =  '' 
    if partner_filter!='':
        where_cond   =  f""" WHERE PRACTICEID in (select PRACTICEID from DIM_PRACTICE where JVPARTNERID = {session['jv_ref']} ) """
    elif practice_id != '':
        where_cond   =  f""" WHERE PRACTICEID = {practice_id} """ 

    pro_rows       = execute_snowflake_query(f"""select INDIVIDUAL_NPI,CONCAT_WS(' ',FIRST_NAME,LAST_NAME) as name from DIM_PROVIDER {where_cond} """)
    provider_data  = {x[0]:x[1] for x in pro_rows if x[0] !=''}  

    return provider_data

def get_practice_data():
    
    partner_id      = request.args.get('partner_id') or ''

    partner_filter  = session['jv_name'] if 'user_type' in session and session['user_type'] == 'ExternalUser' else ''
    ## get the partner names  
    partner_cond   =  '' 
    if partner_filter!='':
        partner_cond   =  f""" WHERE JVPARTNERID = {session['jv_ref']} """
    elif partner_id != '':
        partner_cond   =  f""" WHERE JVPARTNERID = {partner_id} """

    practice_rows  = execute_snowflake_query(f"""select PRACTICEID,PRACTICENAME,ZIP5_CODE as name from DIM_PRACTICE {partner_cond} group by PRACTICEID,PRACTICENAME,ZIP5_CODE """)
    practice_data  = {x[0]:str(x[0])+" "+x[1]+" "+str(x[2]) for x in practice_rows }  

    return practice_data

def check_special_chars():
    error_flag = 0
    for request_param in request.args:
        #print(request.args[request_param])
        if request.args[request_param]!='' and request.args[request_param] is not None:

            special_char_list = SPL_CHARS.split(',')

            for spl_char in special_char_list:
                if str(spl_char).lower() in str(request.args[request_param]).lower():
                    error_flag+=1

    return error_flag;